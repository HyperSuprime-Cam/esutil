A python package including a wide variety of utilities, focused primarily on
numerical python, statistics, and file input/output.   Includes specialized
tools for astronomers.

For full documentation see the project web site http://code.google.com/p/esutil/
