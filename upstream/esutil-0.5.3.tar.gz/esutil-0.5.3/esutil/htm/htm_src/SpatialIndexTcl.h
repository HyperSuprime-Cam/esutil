#include "stdio.h"
#include "SpatialIndex.h"

#define gNameLength        20
#define gLeafNumberLength  20
#define gIDLength          20
#define gFloatLength       20


