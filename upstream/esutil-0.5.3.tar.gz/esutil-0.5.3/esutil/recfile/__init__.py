import Util
from Util import Recfile
from Util import Open
from Util import test

# use the same doc as the Util module
__doc__=Util.__doc__
