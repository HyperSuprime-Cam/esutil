from .import Util
from .Util import Recfile
from .Util import write, read
from .Util import Open
from .test import test

# use the same doc as the Util module
__doc__=Util.__doc__
