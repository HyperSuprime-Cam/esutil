swig -python -c++ -o chist_wrap.cc chist.i
