swig -python -c++ -o cgauleg_wrap.cc cgauleg.i
